 <?php
/**
 * Shore Theme: Blog section, sidebar
 * @package WordPress
 * @subpackage Shore Theme
 * @since 1.0
 * TO BE INCLUDED ON PAGES WITH SIDEBAR: BLOG
 */
 ?>
 <?php if ( dynamic_sidebar('Blog') ) : ?>
<?php endif; ?>